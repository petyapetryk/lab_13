const arr = [1, "a", true, null];

arr.push(prompt("Enter ="));

console.log(arr[5]);

const deleteValue = arr.shift();

console.log(deleteValue);

console.log(arr);