let a = prompt("enert a");
let b = prompt("enert b");

function raiseToDegree(a,b)
{
   return console.log(Math.pow(a,b));
}

raiseToDegree(a,b);