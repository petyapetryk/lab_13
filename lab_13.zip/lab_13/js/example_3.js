let arr = [2, 3, 4, 5];

let sum = 1;

for(let i = 0; i < arr.length; i++) {
    sum *= arr[i];
}

console.log("Добуток = ", sum);