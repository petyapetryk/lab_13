let str = "i love sweet";

let firstStr = str.charAt(0).toUpperCase();

let newStr = firstStr + str.slice(1);

console.log(newStr);