let cities = ["Ternopil", "Lviv", "Warsaw"];

console.log(cities[0] + '*' + cities[1] + '*' + cities[2]);